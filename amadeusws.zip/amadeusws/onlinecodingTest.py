# Databricks notebook source
# MAGIC %md
# MAGIC ### Load the Files

# COMMAND ----------

# Set File Paths 
bookingFilePath ="dbfs:/FileStore/amadeus/bookings_csv.bz2"
searchFilePath ="dbfs:/FileStore/amadeus/searches_csv.bz2"

# Build DataFrames
bookingsDF = spark.read.format("csv").option("header",True).option("inferSchema",True).option("sep","^").load(bookingFilePath)
searchesDF = spark.read.format("csv").option("header",True).option("inferSchema",True).option("sep","^").load(searchFilePath)



# COMMAND ----------

# MAGIC %md
# MAGIC ### Question 1: reading files
# MAGIC ##### Check the number of lines in each of the two files (bookings and searches)

# COMMAND ----------

# Check File/DataFrame Count

print ( "Booking File has got " , bookingsDF.count() , " Lines" )

print ( "Search File has got " , searchesDF.count() , " Lines" )

# COMMAND ----------

# MAGIC %md
# MAGIC ###  Question 2: top 10 arrival airports in the world in 2013 (using the bookings file)

# COMMAND ----------

from pyspark.sql.functions import col,sum,desc

# set the Aggragations
groupingColumns = col("arr_port")
aggrgateColumns = sum(col("pax"))
sortColumns     = desc(col("passenger_count"))

# Top 10 Arrivals
topTenArrivals = bookingsDF.select("arr_port","pax").groupBy(groupingColumns).agg(aggrgateColumns.alias("passenger_count")).sort(sortColumns).limit(10)



# COMMAND ----------

# read the github file using pandas . as this is a small file so can be read thru pandas.
#caution : pandas works on Driver Node . so if the file size is huge , look for some alternate approach

import pandas as pd

# set the URL
url = "https://raw.githubusercontent.com/opentraveldata/opentraveldata/master/opentraveldata/optd_por_ref.csv"
pandas_df = pd.read_csv(sep="^",filepath_or_buffer=url)

# converto to spark Dataframe
airportLookupDF = spark.createDataFrame(pd_df).withColumnRenamed("iata_code","arr_port")





# COMMAND ----------

from pyspark.sql.functions import expr

#set Join Criteria
joinCondition = expr("trim(arptlookupdf.arr_port) = trim(aldf.arr_port)")

# Build the Join
topTenArrivals.alias("aldf").join(airportLookupDF.alias("arptlookupdf") , joinCondition , "inner") \
    .selectExpr("aldf.*","arptlookupdf.cty_code").show()




# COMMAND ----------

# MAGIC %md
# MAGIC ###  Question 3: Matching searches with bookings

# COMMAND ----------

##########################################################################################
#  For every search in the searches file, find out whether the search ended up in a booking or not 
##########################################################################################
######## Logic Implemented  : 
############ 1. Search Date and Booking Date has to be same
############ 2. "Origin Port of Booking"  and "Departure of Search"   has to be same
############ 3. "Arrival Port of Booking" and "Destination of Search" has to be same
##########################################################################################


from pyspark.sql.functions import date_format ,to_date
from pyspark.sql.functions import when,lit

# Build Booking and Search Dataframe with lmited columns
selectedbookingDF = bookingsDF.select( to_date(col('act_date           '),format="yyyyy-MM-dd").alias("book_date"),"arr_port","dep_port")
selectedsearchesDF = searchesDF.select(col("Date").alias("SearchDate"),date_format('Time', 'HH:mm:ss').alias("SearchTime"),"Country","Origin","Destination")

# Set the Join Criteria
joinCondition = expr(" ssdf.SearchDate = sbdf.book_date  and trim(ssdf.Origin)  = trim(sbdf.dep_port)  and trim(ssdf.Destination)  = trim(sbdf.arr_port) ")

# Build the Dataframe with an extra column that will tell us whether a search to booking is successful of not
# type of Join used : LEFT as we need to show all searches with matching Booking
searchHavingBooking = selectedsearchesDF.alias("ssdf").join( selectedbookingDF.alias("sbdf"), joinCondition , "left" ) \
                        .withColumn("has_got_booking", when(col("book_date").isNotNull(),lit(1)).otherwise(lit(0)) ) \
                        .selectExpr("ssdf.*","has_got_booking")
    

selectedbookingDF.show(truncate=False)
selectedsearchesDF.show(truncate=False)
# Final Search Dataframe to Show
searchHavingBooking.show(truncate=False)

# COMMAND ----------

# Write to the Pat in csv format
searchHavingBooking.write.format("csv").option("header",True).save(mode="overwrite" ,path = "dbfs:/FileStore/amadeus/searchOutput.csv")

# COMMAND ----------

#spark.read.format("csv").option("header",True).load("dbfs:/FileStore/amadeus/searchOutput.csv/").show()